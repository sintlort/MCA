<div id="sidebar" class="active">
    <div class="sidebar-wrapper active">
        <div class="sidebar-header">
            <div class="d-flex justify-content-between">
                <div class="logo">
                    <a href="#"><img src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" alt="Logo" srcset=""></a>
                </div>
                <div class="toggler">
                    <a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
                </div>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul class="menu">
                <li class="sidebar-title">Menu</li>

                <li class="sidebar-item <?php echo $__env->yieldContent('data_finance'); ?>  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="bi bi-stack"></i>
                        <span>Fundamental<br>Analysis</span>
                    </a>
                    <ul class="submenu <?php echo $__env->yieldContent('sub_menu'); ?>">
                        <li class="submenu-item <?php echo $__env->yieldContent('yahoo'); ?>">
                            <a href="<?php echo e(route('yahoo_index')); ?>">Yahoo Finance</a>
                        </li>
                        <li class="submenu-item <?php echo $__env->yieldContent('alpha'); ?>">
                            <a href="<?php echo e(route('alpha_index')); ?>">Alphavantage</a>
                        </li>
                    </ul>
                </li>

                <li class="sidebar-item <?php echo $__env->yieldContent('data_finance'); ?>  has-sub">
                    <a href="#" class='sidebar-link'>
                        <i class="bi bi-broadcast"></i>
                        <span>API Page</span>
                    </a>
                    <ul class="submenu <?php echo $__env->yieldContent('sub_menu'); ?>">
                        <li class="submenu-item <?php echo $__env->yieldContent('yahoo'); ?>">
                            <a href="<?php echo e(route('yahoo-api-page')); ?>">Yahoo API</a>
                        </li>
                        <li class="submenu-item <?php echo $__env->yieldContent('alpha'); ?>">
                            <a href="<?php echo e(route('alpha-api-page')); ?>">Alphavantage API</a>
                        </li>
                    </ul>
                </li>

                
            </ul>
        </div>
        <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
    </div>
</div>
<?php /**PATH D:\Programs\XAMPP\htdocs\MCA\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>